import { useRouter } from "next/router";
import Head from "next/head";
const Dynamic = () => {
  const router = useRouter();

  return (
    <div>
      {" "}
      <Head>
        <title>{router.query.id}</title>
      </Head>
      this is page : {router.query.id}
    </div>
  );
};

export default Dynamic;
