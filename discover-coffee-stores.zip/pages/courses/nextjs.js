const NextJs = () => {
  return <div>Welcome to Next.js with Ankita</div>;
};

export default NextJs;
